<?php
namespace __ModuleName__;
return [
    'controllers' => [
        'factories' => [
			'__ModuleName__\Controller\__ModuleName__Controller' => '__ModuleName__\Factory\Controller\__ModuleName__ControllerFactory',
            $controllerFactoryString
        ],
    ],
    'service_manager' => [
        'factories' => [
            '__ModuleName__\Options\ModuleOptions' => '__ModuleName__\Factory\ModuleOptions\ModuleOptionsFactory',
            $serviceFactoryString
        ],
    ],
    'doctrine' => [
        'driver' => [
            __NAMESPACE__ . '_driver' => [
                'class' => 'Doctrine\ORM\Mapping\Driver\AnnotationDriver',
                'cache' => 'array',
                'paths' => __DIR__ . '/../src/'.__NAMESPACE__.'/Entity',
            ],
            'orm_default' => [
                'drivers' => [
                    __NAMESPACE__ . '\Entity' => __NAMESPACE__ . '_driver'
                ],
            ],
        ],
    ],
    'router' => [
        'routes' => [
			'__ModuleNameWithDash__' => [
				'type' => 'Segment' ,
				'options' => [
					'route' => '/__ModuleNameWithDash__',
					'defaults' => [
						'controller' => '__ModuleName__\Controller\__ModuleName__Controller' ,
						'action' => 'index' ,
					],
				],
				'may_terminate' => true,
				'child_routes' => [
					$routeString
				],
			],
		],
    ],
    
    'navigation' => [
        'default' => [
            '__ModuleNameWithDash__' => [
                'label' => '__ModuleName__',
                'route' => '__ModuleNameWithDash__',
                'icon' => 'glyphicon glyphicon-list',
                'resource' => '__ModuleNameWithDash__',
                'privilege' => 'list',
                'show_submenu'=>true,
                'order' => 1000,
                'pages' => [
					$navigationString
				],
            ],
        ],
    ],
    
    'bjyauthorize' => [
        'guards' => [
            'BjyAuthorize\Guard\Controller' => [
				['controller' => '__ModuleName__\Controller\__ModuleName__Controller', 'roles' => ['user']],
                $authorizationControllerString
            ],
            'BjyAuthorize\Guard\Route' => [
				['route' => '__ModuleNameWithDash__', 'roles' => ['user']],
                $authorizationRouteString
            ],
        ],
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
                '__ModuleNameWithDash__' => [],
				$authorizationResourceString
            ],
        ],
        'rule_providers' => [
            'BjyAuthorize\Provider\Rule\Config' => [
                'allow' => [
                    [['user'],'__ModuleNameWithDash__',['list','add','edit','delete']],
					$authorizationRuleProviderString
                ],
            ],
        ],
    ],
    
    'view_manager' => [
        'template_path_stack' => [
            '__ModuleNameWithDash____' => __DIR__ . '/../view',
        ],
    ],
];