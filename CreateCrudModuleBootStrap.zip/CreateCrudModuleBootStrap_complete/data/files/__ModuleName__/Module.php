<?php
namespace __ModuleName__;

class Module
{
    public function getAutoloaderConfig()
    {
        return [
            'Zend\Loader\ClassMapAutoloader' => [
                __DIR__ . '/autoload_classmap.php',
            ],
            'Zend\Loader\StandardAutoloader' => [
                'namespaces' => [
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ],
            ],
        ];
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function onBootstrap($e) {
        
		$sm = $e->getApplication()->getServiceManager();

        $router = $sm->get('router');
        $request = $sm->get('request');
        $matchedRoute = $router->match($request);
        
        if($matchedRoute!==NULL){
            $params = $matchedRoute->getParams();
            $controller = $params['controller'];
            $module_array = explode('\\', $controller);
            $module = $module_array[0];
            if($module==strtolower(__NAMESPACE__) || $module==__NAMESPACE__){
                $sm = $e->getApplication()->getServiceManager();
                
                $headScript = $sm->get('viewhelpermanager')->get('headScript');
                $headScript->appendFile('http://tuservice.dev/AdminLTE/plugins/datatables/jquery.dataTables.min.js');
                $headScript->appendFile('http://tuservice.dev/AdminLTE/plugins/datatables/dataTables.bootstrap.js');
                
                $headStyle = $sm->get('viewhelpermanager')->get('headLink');
                $headStyle->appendStylesheet('http://tuservice.dev/AdminLTE/plugins/datatables/dataTables.bootstrap.css');
            }
        }
		
    }
}