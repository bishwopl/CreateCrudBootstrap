<?php
namespace __ModuleName__\Factory\Service;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

use __ModuleName__\Service\__ModuleName__Service;

class __ModuleName__ServiceFactory implements FactoryInterface
{
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     *
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $em                  = $serviceLocator->get('doctrine.entitymanager.orm_default');
        $options             = $serviceLocator->get('\__ModuleName__\Options\ModuleOptions');
        
        return new __ModuleName__Service($options, $em);
    }
}

