<?php
namespace __ModuleName__\Form\__EntityName__;

use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Zend\Form\Fieldset;
use Zend\InputFilter\InputFilterProviderInterface;

class __EntityName__FormFieldset extends Fieldset implements InputFilterProviderInterface
{
    protected $__EntityNameCamelCase__Service;
    public function __construct(\__ModuleName__\Service\__EntityName__Service $__EntityNameCamelCase__Service, $translator, $id=NULL)
    {
        parent::__construct('crud');
        
        $locale = $translator->getLocale();
        
        $this->__EntityNameCamelCase__Service = $__EntityNameCamelCase__Service;
        
        $objectManager = $__EntityNameCamelCase__Service->getEntityManager();
        
        $this->setHydrator(new DoctrineHydrator($objectManager))
             ->setObject($__EntityNameCamelCase__Service->getEntity());

        $this->setAttribute('class', 'form-horizontal');
        
        $this->add([
            'type' => 'Zend\Form\Element\Hidden',
            'name' => 'id',
            'options' => [
                'label' => '',
            ],
            'attributes' => [
                'id'   => 'id',
            ],
        ]);
        
        $formFieldString;
    }

    public function getInputFilterSpecification()
    {
        return [
            $formValidationString
        ];
    }
}