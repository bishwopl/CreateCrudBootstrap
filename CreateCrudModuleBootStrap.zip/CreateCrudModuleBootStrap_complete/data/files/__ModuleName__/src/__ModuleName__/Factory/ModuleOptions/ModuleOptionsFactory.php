<?php
namespace __ModuleName__\Factory\ModuleOptions;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use __ModuleName__\ModuleOptions\ModuleOptions;

class ModuleOptionsFactory implements FactoryInterface
{

    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $config = $serviceLocator->get('Config');
        return new ModuleOptions(isset($config['__ModuleNameWithUnderScore___module_options']) ? $config['__ModuleNameWithUnderScore___module_options'] : []);        
    }
}
