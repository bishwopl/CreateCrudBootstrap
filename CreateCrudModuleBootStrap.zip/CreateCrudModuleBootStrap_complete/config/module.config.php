<?php
namespace CreateCrudModuleBootStrap;
return [
    'controllers' => [
        'factories' => [
            'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' => 'CreateCrudModuleBootStrap\Factory\Controller\CreateCrudModuleBootStrapControllerFactory',
        ],
    ],
    'service_manager' => [
        'factories' => [
            'CreateCrudModuleBootStrap\Options\ModuleOptions' => 'CreateCrudModuleBootStrap\Factory\ModuleOptions\ModuleOptionsFactory',
            'CreateCrudModuleBootStrap\Service\CreateCrudModuleBootStrapService'   => 'CreateCrudModuleBootStrap\Factory\Service\CreateCrudModuleBootStrapServiceFactory',
        ],
    ],
    'doctrine' => [
        'driver' => [
            __NAMESPACE__ . '_driver' => [
                'class' => 'Doctrine\ORM\Mapping\Driver\AnnotationDriver',
                'cache' => 'array',
                'paths' => __DIR__ . '/../src/'.__NAMESPACE__.'/Entity',
            ],
            'orm_default' => [
                'drivers' => [
                    __NAMESPACE__ . '\Entity' => __NAMESPACE__ . '_driver'
                ],
            ],
        ],
    ],
    'router' => [
        'routes' => [
            'create-crud-module-boot' => [
                'type' => 'Segment' ,
                'options' => [
                    'route' => '/create-crud-module-boot',
                    'defaults' => [
                        'controller' => 'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' ,
                        'action' => 'index' ,
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                    'paged'=> [
                        'type' => 'Segment' ,
                        'options' => [
                            'route' => '[/:id]',
                            'defaults' => [
                                'controller' => 'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' ,
                                'action' => 'list' ,
                            ],
                        ],
                    ],
                    'add' => [
                        'type' => 'literal' ,
                        'options' => [
                            'route' => '/add',
                            'defaults' => [
                                'controller' => 'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' ,
                                'action'     => 'add',
                            ],
                        ],
                    ],
                    'edit' => [
                        'type' => 'segment' ,
                        'options' => [
                            'route' => '/edit[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+' ,
                            ],
                            'defaults' => [
                                'controller' => 'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' ,
                                'action'     => 'edit',
                            ],
                        ],
                    ],
                    'delete' => [
                        'type' => 'Segment' ,
                        'options' => [
                            'route' => '/delete[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+' ,
                            ],
                            'defaults' => [
                                'controller' => 'CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController' ,
                                'action'     => 'delete',
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],

    'view_manager' => [
        'template_path_stack' => [
            'create-crud-module-boot' => __DIR__ . '/../view',
        ],
    ],
];