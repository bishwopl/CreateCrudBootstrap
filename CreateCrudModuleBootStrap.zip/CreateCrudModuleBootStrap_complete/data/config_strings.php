<?php

$controllerFactoryString = "'__ModuleName__\Controller\__EntityName__Controller' => "
        . "'__ModuleName__\Factory\Controller\__EntityName__ControllerFactory',";

$serviceFactoryString = "'__ModuleName__\Service\__EntityName__Service'   => "
        . "'__ModuleName__\Factory\Service\__EntityName__ServiceFactory',";

$routeString = "
'__EntityNameWithDash__' => [
'type' => 'Segment',
 'options' => [
'route' => '/__EntityNameWithDash__',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'index',
],
],
 'may_terminate' => true,
 'child_routes' => [
'list' => [
'type' => 'literal',
 'options' => [
'route' => '/list',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'list',
],
],
],
 'add' => [
'type' => 'literal',
 'options' => [
'route' => '/add',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'add',
],
],
],
 'edit' => [
'type' => 'segment',
 'options' => [
'route' => '/edit[/:id]',
 'constraints' => [
'id' => '[0-9]+',
],
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'edit',
],
],
],
 'delete' => [
'type' => 'Segment',
 'options' => [
'route' => '/delete[/:id]',
 'constraints' => [
'id' => '[0-9]+',
],
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'delete',
],
],
],
],
],
";

$navigationString = "
'__EntityNameWithDash__' => [
'label' => '__EntityName__',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__',
 'icon' => 'glyphicon glyphicon-list',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'list',
 'show_submenu' => false,
 'order' => 1000,
 'pages' => [
'__EntityNameWithDash__-paged' => [
'label' => '',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/paged',
 'icon' => 'glyphicon glyphicon-list',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'list',
],
 '__EntityNameWithDash__-add' => [
'label' => 'Add',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/add',
 'icon' => 'glyphicon glyphicon-plus-sign',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'add',
],
 '__EntityNameWithDash__-edit' => [
'label' => 'Edit',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/edit',
 'icon' => 'glyphicon glyphicon-edit',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'edit',
],
 '__EntityNameWithDash__-delete' => [
'label' => 'Delete',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/delete',
 'icon' => 'glyphicon glyphicon-trash',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'delete',
],
 '__EntityNameWithDash__-list' => [
'label' => 'Detail',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/detail',
 'icon' => 'glyphicon glyphicon-list',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'detail',
],
],
],  
";

$authorizationControllerString = "['controller' => '__ModuleName__\Controller\__EntityName__Controller', 'roles' => ['user']],";

$authorizationRouteString = "['route' => '__ModuleNameWithDash__/__EntityNameWithDash__', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/list', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/add', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/edit', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/delete', 'roles' => ['user']],";

$authorizationResourceString = "'__EntityNameWithDash__' => [],";
$authorizationRuleProviderString = "[['user'],'__EntityNameWithDash__',['list','add','edit','delete']],";