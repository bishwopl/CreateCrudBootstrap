<?php
namespace __ModuleName__\Service;

use Doctrine\Common\Persistence\ObjectManager;
use __ModuleName__\ModuleOptions\ModuleOptions;

class __ModuleName__Service
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $objectManager;
    
    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;

    public function __construct(
            ModuleOptions $options, 
            ObjectManager $objectManager)
    {
        $this->objectManager    = $objectManager;
        $this->options          = $options;
    }
    
    public function getEntityManager(){
        return $this->objectManager;
    }
}

