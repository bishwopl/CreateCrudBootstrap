<?php

namespace __ModuleName__\Service;

use PHPExcel;
use PHPExcel_IOFactory;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityRepository;
use DoctrineORMModule\Paginator\Adapter\DoctrinePaginator;
use Doctrine\ORM\Tools\Pagination\Paginator as ORMPaginator;
use Zend\Paginator\Paginator;
use __ModuleName__\ModuleOptions\ModuleOptions;

class BaseCrudService {

    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $objectManager;

    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;

    /**
     * @var \Doctrine\ORM\EntityRepository
     */
    protected $repository;
    protected $entity;
    protected $renderer;

    public function __construct(
    ModuleOptions $options, ObjectManager $objectManager, EntityRepository $repository, $entity, $renderer) {
        $this->objectManager = $objectManager;
        $this->options = $options;
        $this->repository = $repository;
        $this->entity = $entity;
        $this->renderer = $renderer;
    }

    public function getEntityManager() {
        return $this->objectManager;
    }

    public function getEntity() {
        return $this->entity;
    }

    public function getModuleOptions() {
        return $this->options;
    }

    /**
     * 
     * @param type $searchTerms
     * @param type $sorting
     * @param type $startIndex
     * @param type $pageSize
     * @return Paginator
     */
    public function getListOfRecords($searchTerms = [], $sorting = [['id', 'DESC']], $startIndex = 0, $pageSize = 10) {
        $sortTermCount = 0;
        $sortTerms = [];
        if (!is_array($sorting)) {
            $sorting = [$sorting];
        }
        foreach ($sorting as $s) {
            if (strrpos($s[0], '.') == FALSE) {
                $s[0] = 'u.' . $s[0];
            }
            $sortTerms[$sortTermCount] = [0 => trim($s[0]), 1 => trim($s[1])];
            $sortTermCount++;
        }

        $params = [];
        $paramCount = 0;
        $qb = $this->objectManager->createQueryBuilder();
        $qb->select('u')->from($this->repository->getClassName(), 'u');

        foreach ($sortTerms as $sort) {
            $qb->orderBy($sort[0], $sort[1]);
        }
        foreach ($searchTerms as $key => $value) {
            if (strrpos($key, '.') == FALSE) {
                $key = 'u.' . $key;
            }
            if (is_numeric($value)) {
                $qb->andWhere($qb->expr()->eq($key, '?' . $paramCount));
                $params[$paramCount] = $value;
            } else {
                if ($value == '') {
                    $qb->andWhere(
                            $qb->expr()->orX(
                                    $qb->expr()->like($key, '?' . $paramCount), $qb->expr()->isNull($key)
                            )
                    );
                } else {
                    $qb->andWhere($qb->expr()->like($key, '?' . $paramCount));
                }
                $params[$paramCount] = '%' . $value . '%';
            }
            $paramCount++;
        }

        $qb->setParameters($params);
        $qb->setFirstResult($startIndex);
        $query = $qb->getQuery();
        $paginator = new Paginator(new DoctrinePaginator(new ORMPaginator($query)));

        if ($pageSize > 0) {
            $pageNo = floor($startIndex / $pageSize) + 1;
            $paginator->setCurrentPageNumber($pageNo);
        } else {
            $paginator->setCurrentPageNumber(0);
        }
        $paginator->setItemCountPerPage($pageSize);
        return $paginator;
    }

    public function findRecordById($recordId = 0) {
        $entity = $this->repository->findOneBy(['id' => $recordId]);
        return $entity;
    }

    public function deleteRecord($entity) {
        $this->objectManager->remove($entity);
        $this->objectManager->flush();
    }

    public function saveRecord($entity) {
        if ($entity->getId() == NULL && method_exists($entity, 'setCreated')) {
            $entity->setCreated(new \DateTime());
        }
        $this->objectManager->persist($entity);
        $this->objectManager->flush();
    }

    public function getMaxId() {
        $entityClass = $this->repository->getClassName();
        $qb = $this->objectManager->createQueryBuilder();
        $qb->select('MAX(u.id)')->from($entityClass, 'u');
        $result = $qb->getQuery()->getResult();
        $count = $result[0];
        return $count[1];
    }

    public function getRecordCount($filter = NULL) {
        $qbCount = $this->objectManager->createQueryBuilder();
        $params = [];
        $qbCount->select('COUNT(u)')
                ->from($this->repository->getClassName(), 'u');
        if ($filter != NULL) {
            foreach ($filter as $key => $value) {
                $qbCount->andWhere($qbCount->expr()->eq('u.' . $key, ':' . $key));
                $params[$key] = $value;
            }
        }
        return $qbCount->getQuery()->getSingleScalarResult();
    }

    public function toDataArray($dataArray) {
        
    }
    
    public function getTitles(){
        
    }

    public function exportHtml($titleArray, $dataArray, $template, $itemPerPage) {
        // this makes sure only 50*3 files will be stored in export directory
        // otherwise each export creaes a new file and takes up huge space in long run
        $randomNumber = rand(100, 149);
        $fileNameHtml = $this->getExportPath() . '/' . $randomNumber . '.html';

        if ($template == '') {
            return false;
        }

        $viewModel = new \Zend\View\Model\ViewModel();
        $viewModel->setTerminal(true);
        $viewModel->setVariable('titles', $titleArray);
        $viewModel->setVariable('records', $dataArray);
        $viewModel->setVariable('itemPerPage', $itemPerPage);
        $viewModel->setTemplate($template);

        $html = $this->renderer->render($viewModel);

        $handle = fopen($fileNameHtml, 'w');
        fwrite($handle, $html);
        fclose($handle);
        return $fileNameHtml;
    }

    public function exportPdf($titleArray, $dataArray, $template, $itemPerPage) {
        $inputFileName = $this->exportHtml($titleArray, $dataArray, $template, $itemPerPage);
        $outputFileName = false;
        if (file_exists($inputFileName)) {
            $outputFileName = str_replace(".html", '.pdf', $inputFileName);
            if ($this->options->getHtmlToPdfCommandPath() != '') {
                $cmd = $this->options->getHtmlToPdfCommandPath() . ' ' . $inputFileName . ' ' . $outputFileName;
                shell_exec($cmd);
            }
        }
        return $outputFileName;
    }

    public function exportCsv($titleArray, $dataArray, $template, $itemPerPage) {
        $inputFileName = $this->exportHtml($titleArray, $dataArray, $template, $itemPerPage);
        $outputFileName = false;
        if (file_exists($inputFileName)) {
            $inputFileType = 'HTML';
            $outputFileType = 'Excel2007';
            $outputFileName = str_replace(".html", '.xlsx', $inputFileName);

            $objPHPExcelReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objPHPExcelReader->load($inputFileName);

            $objPHPExcelWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, $outputFileType);
            $objPHPExcel = $objPHPExcelWriter->save($outputFileName);
        }
        return $outputFileName;
    }

    protected function getExportPath() {
        $dir = getcwd() . '/data';
        if (!is_dir($dir)) {
            mkdir($dir);
        }
        $dir1 = getcwd() . '/data/exports';
        if (!is_dir($dir1)) {
            mkdir($dir1);
        }
        return $dir1;
    }

}
