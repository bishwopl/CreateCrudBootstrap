<?php
namespace CreateCrudModuleBootStrap\Form;

use Zend\Form\Form;
use Zend\InputFilter\InputFilterProviderInterface;
use Zend\Form\Element;

class CreateCrudModuleBootStrapForm extends Form implements InputFilterProviderInterface{
    public function __construct($name = null, $options = array()) {
        parent::__construct($name, $options);
        $this->setAttribute('METHOD', 'POST');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('action', '/create-crud-module-boot');
        $this->add(array(
            'name' => 'moduleName',
            'options' => array(
                'label' => 'Module Name',
            ),
            'attributes' => array(
                'type'           => 'text',
                'class'          => 'form-control input-sm',
            ),
        ));
        
        $textarea = new Element\Textarea('TextArea');
        $textarea->setName('tableNames');
        $textarea->setAttribute('class', 'form-control input-sm');
        $textarea->setLabel('Table Names');
        $this->add($textarea);

        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Submit',
                'class' => 'btn btn-sm btn-primary'
            ),
        ));
    }
    public function getInputFilterSpecification()
    {
        return [
            'moduleName'  => ['required' => true,],
            'tableNames' => ['required' => false,],
        ];
    }
}
