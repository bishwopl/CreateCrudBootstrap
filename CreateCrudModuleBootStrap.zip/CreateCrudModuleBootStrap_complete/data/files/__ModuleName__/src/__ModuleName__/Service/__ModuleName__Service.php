<?php
namespace __ModuleName__\Service;

use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityRepository;

use __ModuleName__\ModuleOptions\ModuleOptions;

class __ModuleName__Service
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $objectManager;
    
    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;
    protected $dependentRepos;

    public function __construct(
            ModuleOptions $options, 
            ObjectManager $objectManager,
            $dependentRepos)
    {
        $this->objectManager    = $objectManager;
        $this->options          = $options;
        $this->dependentRepos   = $dependentRepos;
    }
    
    public function getEntityManager(){
        return $this->objectManager;
    }
    protected function getRecords(
            EntityRepository $repository, 
            $searchTerms=[], 
            $sorting=['id DESC'], 
            $startIndex=0, 
            $pageSize=10)
    {
        $sortTermCount = 0;
        $sortTerms = [];
        if(!is_array($sorting)){
            $sorting = [$sorting];
        }
        foreach($sorting as $s){
            $dummy = explode(' ', $s);
            if(sizeof($dummy) == 2){
                $sortTerms[$sortTermCount][0] = trim($dummy[0]);
                $sortTerms[$sortTermCount][1] = trim($dummy[1]);
                $sortTermCount++;
            }
        }
        //var_dump($sortTerms);
        $params = [];
        $qb = $this->objectManager->createQueryBuilder();
        $qbCount = $this->objectManager->createQueryBuilder();
        $qbCount->select('COUNT(u)')
            ->from($repository->getClassName(), 'u');
        $qb->select('u')
            ->from($repository->getClassName(), 'u');
        foreach($sortTerms as $sort){
            $qb->orderBy('u.'.$sort[0], $sort[1]);
        }
        foreach ($searchTerms as $key => $value) {
            if (trim($value == '')) {
                continue;
            }
            $isNum = filter_var($value, FILTER_VALIDATE_FLOAT) || filter_var($value, FILTER_VALIDATE_INT);
            if (!$isNum) {//then the value is sting so we need like function
                $qbCount->andWhere(
                        $qbCount->expr()->orX(
                                $qbCount->expr()->like('u.' . $key, ':' . $key), $qbCount->expr()->isNull('u.' . $key)
                        )
                );
                $qb->andWhere(
                        $qb->expr()->orX(
                                $qb->expr()->like('u.' . $key, ':' . $key), $qb->expr()->isNull('u.' . $key)
                        )
                );
                $params[$key] = '%' . $value . '%';
                //echo 'like';
            } else {
                $qb->andWhere($qb->expr()->eq('u.' . $key, ':' . $key));
                $qbCount->andWhere($qb->expr()->eq('u.' . $key, ':' . $key));
                $params[$key] = $value;
                //echo 'equal';
            }
        }
        
        if(sizeof($params)>0){
            $qbCount->setParameters($params);
            $qb->setParameters($params);
        }
        
        $totalRecords = $qbCount->getQuery()->getSingleScalarResult();
        
        $qb->setFirstResult($startIndex);
        if($pageSize!=0){ $qb->setMaxResults($pageSize); }
        
        $result = $qb->getQuery()->getResult();
        
        return ['data'=>$result, 'totalRecord'=>$totalRecords];
        
    }

    public function getOptions($option, $searchTerms, $resultLimit=0){
        if(!array_key_exists($option, $this->dependentRepos)){
            return false;
        }
        $repository = $this->dependentRepos[$option];
        $result = $this->getRecords($repository, $searchTerms, [], 0, $resultLimit);
        return $result;
    }
}

