<?php
namespace CreateCrudModuleBootStrap\Factory\Controller;

use CreateCrudModuleBootStrap\Controller\CreateCrudModuleBootStrapController;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class CreateCrudModuleBootStrapControllerFactory implements FactoryInterface
{
    public function __invoke(\Interop\Container\ContainerInterface $serviceManager, $requestedName, array $options = null)
    {
        return $this->createService($serviceManager);
    }
    
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     *
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $realServiceLocator  = $serviceLocator->getServiceLocator();
        $em                  = $realServiceLocator->get('doctrine.entitymanager.orm_default');
        $options             = $realServiceLocator->get(\CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions::class);
        $CreateCrudModuleBootStrapService         = $realServiceLocator->get(\CreateCrudModuleBootStrap\Service\CreateCrudModuleBootStrapService::class);
        $translator          = $realServiceLocator->get('translator');
        return new CreateCrudModuleBootStrapController($options, $CreateCrudModuleBootStrapService, $em, $translator);
    }
}

