<?php
namespace __ModuleName__\Service;

use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityRepository;

use __ModuleName__\ModuleOptions\ModuleOptions;

class __EntityName__Service
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $objectManager;
    
    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;
    
    /**
     * @var \Doctrine\ORM\EntityRepository
     */
    protected $repository;
    
    protected $entity;

    public function __construct(
            ModuleOptions $options, 
            ObjectManager $objectManager, 
            EntityRepository $repository,
            $entity)
    {
        $this->objectManager = $objectManager;
        $this->options       = $options;
        $this->repository    = $repository;
        $this->entity        = $entity;
    }
    
    public function getEntityManager(){
        return $this->objectManager;
    }
    
    public function getListOfRecords($searchTerms=[], $sorting=[['id','DESC']], $startIndex=0, $pageSize=10){
        $sortTermCount = 0;
        $sortTerms = [];
        if(!is_array($sorting)){
            $sorting = [$sorting];
        }
        foreach($sorting as $s){
            $sortTerms[$sortTermCount][0] = trim($s[0]);
            $sortTerms[$sortTermCount][1] = trim($s[1]);
            $sortTermCount++;
        }
        //var_dump($sortTerms);
        $params = [];
        $qb = $this->objectManager->createQueryBuilder();
        $qbCount = $this->objectManager->createQueryBuilder();
        $qbCount->select('COUNT(u)')
            ->from($this->repository->getClassName(), 'u');
        $qb->select('u')
            ->from($this->repository->getClassName(), 'u');
        foreach($sortTerms as $sort){
            $qb->orderBy('u.'.$sort[0], $sort[1]);
        }
        foreach($searchTerms as $key=>$value){
            if(is_string($value)){//then the value is sting so we need like function
                if($value==''){
                    $qbCount->andWhere(
                        $qbCount->expr()->orX(
                            $qbCount->expr()->like('u.'.$key, ':'.$key),
                            $qbCount->expr()->isNull('u.'.$key)
                        )
                    );
                    $qb->andWhere(
                        $qb->expr()->orX(
                            $qb->expr()->like('u.'.$key, ':'.$key),
                            $qb->expr()->isNull('u.'.$key)
                        )
                    );
                }
                else{
                    $qb->andWhere($qb->expr()->like('u.'.$key, ':'.$key));
                    $qbCount->andWhere($qb->expr()->like('u.'.$key, ':'.$key));
                }
                $params[$key] = '%'.$value.'%';
                //echo 'like';
            }
            else{
                $qb->andWhere($qb->expr()->eq('u.'.$key, ':'.$key));
                $qbCount->andWhere($qb->expr()->eq('u.'.$key, ':'.$key));
                $params[$key] = $value;
                //echo 'equal';
            }
        }
        
        if(sizeof($params)>0){
            $qbCount->setParameters($params);
            $qb->setParameters($params);
        }
        
        $totalRecords = $qbCount->getQuery()->getSingleScalarResult();
        
        $qb->setFirstResult($startIndex);
        $qb->setMaxResults($pageSize);
        
        $result = $qb->getQuery()->getResult();
        
        return ['data'=>$result, 'recordsTotal'=>$totalRecords];
    }
    
    public function findRecordById($recordId=0){
        return $this->repository->findOneBy(['id'=>$recordId]);
    }
    
    public function saveRecord($entity){
        $this->objectManager->persist($entity);
        $this->objectManager->flush();
    }

    public function deleteRecord($entity){
        $this->objectManager->remove($entity);
        $this->objectManager->flush();
    }
    
    public function getEntity(){
        return $this->entity;
    }
}

