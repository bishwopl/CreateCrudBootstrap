<?php

$controllerFactoryString = "'__ModuleName__\Controller\__EntityName__Controller' => "
        . "'__ModuleName__\Factory\Controller\__EntityName__ControllerFactory',";

$serviceFactoryString = "'__ModuleName__\Service\__EntityName__Service'   => "
        . "'__ModuleName__\Factory\Service\__EntityName__ServiceFactory',";

$routeString = "
'__EntityNameWithDash__' => [
'type' => 'Segment',
 'options' => [
'route' => '/__EntityNameWithDash__',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'index',
],
],
 'may_terminate' => true,
 'child_routes' => [
'list' => [
'type' => 'literal',
 'options' => [
'route' => '/list',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'list',
],
],
],
 'add' => [
'type' => 'literal',
 'options' => [
'route' => '/add',
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'add',
],
],
],
 'edit' => [
'type' => 'segment',
 'options' => [
'route' => '/edit[/:id]',
 'constraints' => [
'id' => '[0-9]+',
],
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'edit',
],
],
],
 'delete' => [
'type' => 'Segment',
 'options' => [
'route' => '/delete[/:id]',
 'constraints' => [
'id' => '[0-9]+',
],
 'defaults' => [
'controller' => '__ModuleName__\Controller\__EntityName__Controller',
 'action' => 'delete',
],
],
],
],
],
";

$navigationString = "
'__EntityNameWithDash__' => [
'label' => '__EntityName__',
 'route' => '__ModuleNameWithDash__/__EntityNameWithDash__',
 'icon' => 'glyphicon glyphicon-list',
 'resource' => '__EntityNameWithDash__',
 'privilege' => 'list',
],  
";

$authorizationControllerString = "['controller' => '__ModuleName__\Controller\__EntityName__Controller', 'roles' => ['user']],";

$authorizationRouteString = "['route' => '__ModuleNameWithDash__/__EntityNameWithDash__', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/list', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/add', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/edit', 'roles' => ['user']],
 ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/delete', 'roles' => ['user']],";

$authorizationResourceString = "'__EntityNameWithDash__' => [],";
$authorizationRuleProviderString = "[['user'],'__EntityNameWithDash__',['list','add','edit','delete']],";