<?php
namespace __ModuleName__\Service;

use __ModuleName__\Service\BaseCrudService;

class __EntityName__Service extends BaseCrudService
{
    public function toDataArray($dataArray=[]) {
        $ret = [];
        $count = 1;
        foreach($dataArray as $r){
            if($r instanceof \Application\Entity\__EntityName__){
                $ret[] = [
                    'sn' => ($count++),
                    'id' => $r->getId(),
                    $displayRowString
                ];
            }
        }
        return $ret;
    }
    
    public function getTitles() {
        return [
            'sn',
            'id',
            __TableTitlesInArray__
        ];
    }
}

