<?php
namespace __ModuleName__\Form\__EntityName__;

use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Zend\Form\Form;
use __ModuleName__\Form\__EntityName__\__EntityName__FormFieldset;

class __EntityName__Form extends Form
{
    public function __construct(\__ModuleName__\Service\__EntityName__Service $__EntityNameCamelCase__Service, $translator, $id=NULL)
    {
        parent::__construct('__EntityNameWithDash__-form');
        
        $objectManager = $__EntityNameCamelCase__Service->getEntityManager();
        $this->setHydrator(new DoctrineHydrator($objectManager));
        
        $__EntityNameCamelCase__FormFieldset = new __EntityName__FormFieldset($__EntityNameCamelCase__Service, $translator, $id);
        $__EntityNameCamelCase__FormFieldset->setUseAsBaseFieldset(true);
        $this->add($__EntityNameCamelCase__FormFieldset);
        
        $this->setAttribute('enctype', 'multipart/form-data');
        $this->setAttribute('METHOD', 'POST');
        $this->setAttribute('class', 'form-horizontal');
        
        $this->add([
            'name' => 'submit',
            'attributes' => [
                'type'  => 'submit',
                'value' => 'Submit',
                'id'    => 'submitButton',
                'class' => 'btn btn-primary'
            ],
        ]);
    }
}

