<?php
namespace Setting\Form\__EntityName__;

use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Zend\Form\Form;
class __EntityName__SearchForm extends Form{
    public function __construct(\Setting\Service\__EntityName__Service $__EntityNameCamelCase__Service, $translator, $id = NULL) {
        parent::__construct('__EntityNameCamelCase___search_form');
        $objectManager = $__EntityNameCamelCase__Service->getEntityManager();
        $this->setHydrator(new DoctrineHydrator($objectManager));

        $this->setAttribute('enctype', 'multipart/form-data');
        $this->setAttribute('METHOD', 'POST');
        $this->setAttribute('class', 'form-horizontal');

        $searchFormFieldString;
        
        $this->add(array(
            'name' => 'itemPerPage',
            'type' => '\Zend\Form\Element\Number',
            'options' => array(
                'label' => 'Record Per Page',
            ),
            'attributes' => array(
                'class' => 'form-control input input-sm',
                'min' => 1,
                'required' => 'true',
                'title' => $translator->translate('Record Per Page'),
                'value' => '25'
            ),
        ));
        
        $this->add([
            'name' => 'submit',
            'attributes' => [
                'type' => 'submit',
                'value' => 'Submit',
                'id' => 'submitButton',
                'class' => 'btn btn-primary'
            ],
        ]);
    }

    public function getInputFilterSpecification() {
        return [
            
        ];
    }

}
