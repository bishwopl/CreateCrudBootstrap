<?php
namespace __ModuleName__\Controller;

use Doctrine\Common\Persistence\ObjectManager;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use __ModuleName__\Service\__ModuleNameCamelCase__Service;
use __ModuleName__\ModuleOptions\ModuleOptions;

class __ModuleName__Controller extends AbstractActionController
{
    /**
     * @var \Doctrine\Common\Persistence\ObjectManager
     */
    protected $objectManager;
    
    /**
     * @var \__ModuleName__\Service\__ModuleNameCamelCase__Service
     */
    protected $__ModuleNameCamelCase__Service;
    
    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;
    
    protected $translator;

    public function __construct(
            ModuleOptions $options,
            __ModuleNameCamelCase__Service $__ModuleNameCamelCase__Service,
            ObjectManager $em, 
            $translator)
    {
        $this->options       = $options;
        $this->__ModuleNameCamelCase__Service   = $__ModuleNameCamelCase__Service;
        $this->objectManager = $em;
        $this->translator    = $translator;
    }
    
    public function indexAction() 
    {
        return new ViewModel();
    }
}
