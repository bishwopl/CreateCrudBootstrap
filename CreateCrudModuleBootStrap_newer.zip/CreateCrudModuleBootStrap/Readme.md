Works for both zf2 and zf3
