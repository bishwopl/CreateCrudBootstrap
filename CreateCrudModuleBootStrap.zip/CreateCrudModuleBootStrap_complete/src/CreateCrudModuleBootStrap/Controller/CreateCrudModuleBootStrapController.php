<?php
namespace CreateCrudModuleBootStrap\Controller;

use Doctrine\Common\Persistence\ObjectManager;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use CreateCrudModuleBootStrap\Service\CreateCrudModuleBootStrapService;
use CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions;
use CreateCrudModuleBootStrap\Form\CreateCrudModuleBootStrapForm;

class CreateCrudModuleBootStrapController extends AbstractActionController
{
    /**
     * @var \Doctrine\Common\Persistence\ObjectManager
     */
    protected $objectManager;
    
    /**
     * @var \CreateCrudModuleBootStrap\Service\CreateCrudModuleBootStrapService
     */
    protected $CreateCrudModuleBootStrapService;
    
    /**
     * @var \CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions
     */
    protected $options;
    
    protected $translator;
    
    protected $configString;
    
    protected $association;

    protected $tableDescription;

    public function __construct(
            ModuleOptions $options, 
            CreateCrudModuleBootStrapService $CreateCrudModuleBootStrapService, 
            ObjectManager $em, 
            $translator)
    {
        $this->options       = $options;
        $this->CreateCrudModuleBootStrapService   = $CreateCrudModuleBootStrapService;
        $this->objectManager = $em;
        $this->translator    = $translator;
        $this->configString  = [];
        $this->association  = [];
        $this->tableDescription  = [];
    }
    
    public function indexAction() {
        $tableNames = $this->CreateCrudModuleBootStrapService->getTableNames();
        $this->association = $this->CreateCrudModuleBootStrapService->getAssociation();
        $this->tableDescription = $this->CreateCrudModuleBootStrapService->getTableDescription();

        foreach ($tableNames as $t){
            echo $t.', ';
        }
        
        $form = new CreateCrudModuleBootStrapForm();

        if ($this->getRequest()->isPost()) { 
            $form->setData($this->getRequest()->getPost());
            if($form->isValid()){
                $data = $form->getData();
                $moduleName = $data['moduleName'];
                $tableNames = explode(',', str_replace(' ', '', $data['tableNames']));
                if(!is_array($tableNames)){
                    $tableNames = [$tableNames];
                }
                
                //echo '<br><br><br><br>'.$this->getSaveDirectory();
                
                $this->getConfigStrings($moduleName, $tableNames);
                foreach ($tableNames as $tableName){
                    $this->createFileStructure($moduleName, $tableName, $this->getSaveDirectory());
                }
            }
        }
        return new ViewModel(['form'=>$form]);
    }

    public function createFileStructure($moduleName, $tableName, $saveDirectory, $templateDirectory=''){
        if($templateDirectory == ''){
            $templateDirectory = getcwd().'/module/CreateCrudModuleBootStrap/data/files';
        }
        
        $contents = array_diff(scandir($templateDirectory), ['.', '..']);
        foreach($contents as $name){
            if(is_dir($templateDirectory.'/'.$name)){
                $newName = $this->replaceNames($name, $moduleName, $tableName);
                @mkdir($saveDirectory.'/'.$newName);
                $this->createFileStructure($moduleName, $tableName, $saveDirectory.'/'.$newName, $templateDirectory.'/'.$name);
            }
            else{
                $newFileName    = $this->replaceNames($name, $moduleName, $tableName);
                $fileContent    = file_get_contents($templateDirectory.'/'.$name);
                $newFileContent = $this->replaceNames($fileContent, $moduleName, $tableName);
                $fileHandle     = fopen($saveDirectory.'/'.$newFileName, "w");
                @fwrite($fileHandle, $newFileContent);
                @fclose($fileHandle);
            }
        }
    }
    
    public function replaceNames($text, $moduleName, $tableName){
        $entityName = $this->CreateCrudModuleBootStrapService->tableToEntityName($tableName);
        
        $moduleNameWithDash = strtolower(
            preg_replace(
                ["/([A-Z]+)/", "/_([A-Z]+)([A-Z][a-z])/"], ["-$1", "-$1-$2"], lcfirst($moduleName)
            )
        );
        $moduleNameWithUnderscore = strtolower(
            preg_replace(
                ["/([A-Z]+)/", "/_([A-Z]+)([A-Z][a-z])/"], ["_$1", "_$1_$2"], lcfirst($moduleName)
            )
        );
        $moduleNameLowerCase = strtolower($moduleName);
        $moduleNameCamelCase = lcfirst($moduleName);
        
        $entityNameWithDash = strtolower(
            preg_replace(
                ["/([A-Z]+)/", "/_([A-Z]+)([A-Z][a-z])/"], ["-$1", "-$1-$2"], lcfirst($entityName)
            )
        );
        $entityNameWithUnderscore = strtolower(
            preg_replace(
                ["/([A-Z]+)/", "/_([A-Z]+)([A-Z][a-z])/"], ["_$1", "_$1_$2"], lcfirst($entityName)
            )
        );
        $entityNameLowerCase = strtolower($entityName);
        $entityNameCamelCase = lcfirst($entityName);
        
        $str = [];
        $str['__ModuleName__'] = $moduleName;
        $str['__ModuleNameWithDash__'] = $moduleNameWithDash;
        $str['__ModuleNameCamelCase__'] = $moduleNameCamelCase;
        $str['__ModuleNameWithUnderscore___'] = $moduleNameWithUnderscore;
        $str['__ModuleNameLowerCase__'] = $moduleNameLowerCase;
        $str['__TableName__'] = $tableName;
        
        $str['__EntityName__'] = $entityName;
        $str['__EntityNameWithDash__'] = $entityNameWithDash;
        $str['__EntityNameCamelCase__'] = $entityNameCamelCase;
        $str['__EntityNameWithUnderscore___'] = $entityNameWithUnderscore;
        $str['__EntityNameLowerCase__'] = $entityNameLowerCase;
        
        $strAll = array_merge($str, $this->configString, $this->getSpecializedConfigString($moduleName, $tableName));
        
        foreach($strAll as $key=>$replace){
            $text = str_replace($key, $replace, $text);
        }
        return $text;
    }

    private function getSaveDirectory(){
        $saveDirectory = getcwd().'/data/CreateCrudModuleBootStrap';
        if(file_exists($saveDirectory)){
            //$this->rmdir_recursive($saveDirectory);
        }
        if(!file_exists($saveDirectory)){
            mkdir($saveDirectory);
        }
        return $saveDirectory;
    }

    private function rmdir_recursive($dir) {
        foreach(scandir($dir) as $file) {
            if ('.' === $file || '..' === $file) {
                continue;
            }
            if (is_dir("$dir/$file")) {
                $this->rmdir_recursive("$dir/$file");
            }
            else {
                unlink("$dir/$file");
            }
        }
        rmdir($dir);
    }
    
    private function getSpecializedConfigString($moduleName, $tableName){
        $specializedConfigString = [];
        $moduleNameWithDash = strtolower(
            preg_replace(
                ["/([A-Z]+)/", "/_([A-Z]+)([A-Z][a-z])/"], ["-$1", "-$1-$2"], lcfirst($moduleName)
            )
        );
        $formFieldString        = "";
        $formValidationString   = "";
        $displayRowString       = "";
        $displaySingleRowString = "";
        $displayRowJtableString = "";
        $__TableColumnNames__   = "";
        $__ColumnConfig__       = "";
        
        $columns = $this->tableDescription[$tableName];
        
        foreach($columns as $key=>$col){
            $fieldName = $this->CreateCrudModuleBootStrapService->colNameToFieldName($key);
            if($key!='id'){
                $__TableColumnNames__ .= "<th>".str_replace('Id', '', $fieldName)."</th>"."\n";
                
                if(isset($this->association[$tableName])&&isset($this->association[$tableName][$key])){
                    $fieldName = str_replace('Id', '', $fieldName);
                    $dependentEntity = $this->CreateCrudModuleBootStrapService->tableToEntityName($this->association[$tableName][$key]['REFERENCED_TABLE_NAME']);
                    $formFieldString .= '$this->add(['."\n"
                            . '"name" => "'.$fieldName.'",'."\n"
                            . '"type" => "DoctrineModule\Form\Element\ObjectSelect", '."\n"
                            . '"options" => ['."\n"
                                . '"label" => $translator->translate("'.$dependentEntity.'"),'."\n"
                                . '"object_manager" => $objectManager,'."\n"
                                . '"target_class" => "'.$moduleName.'\Entity\\'.$dependentEntity.'", '."\n"
                                . '"property" => "id", '."\n"
                                . '"display_empty_item" => true,'."\n"
                                . '"empty_item_label"   => "Select ".$translator->translate("'.$fieldName.'"),'."\n"
                            . '],'."\n"
                            . '"attributes" => [ '."\n"
                                . '"class" => "form-control input selectpicker",'."\n"
                                . '"id" => "'.$fieldName.'_id",'."\n"
                                . '"placeholder"=>$translator->translate("'.$fieldName.'"),'."\n"
                            . ']'."\n"
                        . ']);'."\n";
                    
                }
                else{
                    if(!($fieldName=='created'||$fieldName=='lastModified')){
                        $formFieldString .= '$this->add(['."\n"
                            . '"type" => "Zend\Form\Element\Text", '."\n"
                            . '"name" => "'.$fieldName.'", '."\n"
                            . '"options" => ['."\n"
                                . '"label" => "'.$fieldName.'",], '."\n"
                                . '"attributes" => ['."\n"
                                . '"id"   => "'.$fieldName.'_id", '."\n"
                                . '"placeholder"=>$translator->translate("'.$fieldName.'"),'."\n"
                                . '"class" => "form-control input",'."\n"
                            . '],'."\n"
                        . ']);'."\n";
                    }
                }
                
                $__ColumnConfig__ .= '{'."\n"
                    . '"data": "'.$fieldName.'",'."\n"
                    . '"name": "'.$fieldName.'",'."\n"
                . '},'."\n";
                
                $required = $col['Null']=="NO"?"true":"false";
                
                if(!($fieldName=='created'||$fieldName=='lastModified')){
                    $formValidationString .= '"'.$fieldName.'" => ['."\n"
                        . '"required"=>'.$required.', '."\n"
                        . '"filters" => [],'."\n"
                        . '"validators" => [],'."\n".'],'."\n";
                }
                if(isset($this->association[$tableName])&&isset($this->association[$tableName][$key])){
                    $dependentColName = $this->CreateCrudModuleBootStrapService->tableToEntityName($fieldName);
                    $depCallMethod = '$r->get'.$dependentColName.'()';
                    
                    $displayRowString .= '"'.lcfirst($fieldName).'"=>'
                            . '('.$depCallMethod.'==NULL?'.$depCallMethod.':'.$depCallMethod.'->getId()),'."\n";
                }
                else{
                    $colType = $col['Type'];
                    $callMethod = '$r->get'. ucwords($fieldName).'()';
                    $extMethod = '';
                    if(strpos($colType, 'datetime')!==false){
                        $extMethod = '->format(\'Y-m-d H:i:s\')';
                    }
                    elseif(strpos($colType, 'timestamp')!==false){
                        $extMethod = '->format(\'Y-m-d H:i:s\')';
                    }
                    elseif(strpos($colType, 'date')!==false){
                        $extMethod = '->format(\'Y-m-d\')';
                    }
                    elseif(strpos($colType, 'time')!==false){
                        $extMethod = '->format(\'H:i:s\')';
                    }
                    elseif(strpos($colType, 'year')!==false){
                        $extMethod = '->format(\'Y\')';
                    }
                    if($extMethod!=''){
                        $displayRowString .= '"'.lcfirst($fieldName).'"=>'
                            . '('.$callMethod.'!==NULL?'.$callMethod.$extMethod.':'.$callMethod.'),'."\n";
                    }
                    else{
                        $displayRowString .= '"'.lcfirst($fieldName).'"=>'.$callMethod.','."\n";
                    }
                }
            }
        }
        
        $specializedConfigString['$formFieldString']        = $formFieldString;
        $specializedConfigString['$formValidationString']   = $formValidationString;
        $specializedConfigString['$displayRowString']       = $displayRowString;
        $specializedConfigString['$displaySingleRowString'] = $displaySingleRowString;
        $specializedConfigString['$displayRowJtableString'] = $displayRowJtableString;
        $specializedConfigString['__TableColumnNames__']    = $__TableColumnNames__;
        $specializedConfigString['__ColumnConfig__']        = $__ColumnConfig__;
        
        return $specializedConfigString;
    }

    private function getConfigStrings($moduleName, $tableNames){
        $entityNames = $this->CreateCrudModuleBootStrapService->getEntityNames($tableNames);
        
        if($this->configString!=NULL){
            return $this->configString;
        }
        
        $controllerFactoryString = "'__ModuleName__\Controller\__EntityName__Controller' => "
        . "'__ModuleName__\Factory\Controller\__EntityName__ControllerFactory',";

        $serviceFactoryString = "'__ModuleName__\Service\__EntityName__Service'   => "
                . "'__ModuleName__\Factory\Service\__EntityName__ServiceFactory',";

        $routeString = "
        '__EntityNameWithDash__' => [
        'type' => 'Segment',
         'options' => [
        'route' => '/__EntityNameWithDash__',
         'defaults' => [
        'controller' => '__ModuleName__\Controller\__EntityName__Controller',
         'action' => 'index',
        ],
        ],
         'may_terminate' => true,
         'child_routes' => [
        'list' => [
        'type' => 'literal',
         'options' => [
        'route' => '/list',
         'defaults' => [
        'controller' => '__ModuleName__\Controller\__EntityName__Controller',
         'action' => 'list',
        ],
        ],
        ],
         'add' => [
        'type' => 'literal',
         'options' => [
        'route' => '/add',
         'defaults' => [
        'controller' => '__ModuleName__\Controller\__EntityName__Controller',
         'action' => 'add',
        ],
        ],
        ],
         'edit' => [
        'type' => 'segment',
         'options' => [
        'route' => '/edit[/:id]',
         'constraints' => [
        'id' => '[0-9]+',
        ],
         'defaults' => [
        'controller' => '__ModuleName__\Controller\__EntityName__Controller',
         'action' => 'edit',
        ],
        ],
        ],
         'delete' => [
        'type' => 'Segment',
         'options' => [
        'route' => '/delete[/:id]',
         'constraints' => [
        'id' => '[0-9]+',
        ],
         'defaults' => [
        'controller' => '__ModuleName__\Controller\__EntityName__Controller',
         'action' => 'delete',
        ],
        ],
        ],
        ],
        ],
        ";

        $navigationString = "
        '__EntityNameWithDash__' => [
        'label' => '__EntityName__',
         'route' => '__ModuleNameWithDash__/__EntityNameWithDash__',
         'icon' => 'glyphicon glyphicon-list',
         'resource' => '__EntityNameWithDash__',
         'privilege' => 'list',
         'show_submenu' => false,
         'order' => 1000,
         'pages' => [
         '__EntityNameWithDash__-add' => [
        'label' => 'Add',
         'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/add',
         'icon' => 'glyphicon glyphicon-plus-sign',
         'resource' => '__EntityNameWithDash__',
         'privilege' => 'add',
        ],
         '__EntityNameWithDash__-edit' => [
        'label' => 'Edit',
         'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/edit',
         'icon' => 'glyphicon glyphicon-edit',
         'resource' => '__EntityNameWithDash__',
         'privilege' => 'edit',
        ],
         '__EntityNameWithDash__-delete' => [
        'label' => 'Delete',
         'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/delete',
         'icon' => 'glyphicon glyphicon-trash',
         'resource' => '__EntityNameWithDash__',
         'privilege' => 'delete',
        ],
         '__EntityNameWithDash__-list' => [
        'label' => 'Detail',
         'route' => '__ModuleNameWithDash__/__EntityNameWithDash__/detail',
         'icon' => 'glyphicon glyphicon-list',
         'resource' => '__EntityNameWithDash__',
         'privilege' => 'detail',
        ],
        ],
        ],  
        ";

        $authorizationControllerString = "['controller' => '__ModuleName__\Controller\__EntityName__Controller', 'roles' => ['user']],";

        $authorizationRouteString = "['route' => '__ModuleNameWithDash__/__EntityNameWithDash__', 'roles' => ['user']],
         ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/list', 'roles' => ['user']],
         ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/add', 'roles' => ['user']],
         ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/edit', 'roles' => ['user']],
         ['route' => '__ModuleNameWithDash__/__EntityNameWithDash__/delete', 'roles' => ['user']],";

        $authorizationResourceString = "'__EntityNameWithDash__' => [],";
        $authorizationRuleProviderString = "[['user'],'__EntityNameWithDash__',['list','add','edit','delete']],";
        
        $displayOptionsString = 'case "__TableName__":{foreach($this->data as $r){ $return["Options"][] = ["DisplayText"=>$r->getId(),"Value"=>$r->getId()]; } break;}';
        
        $ret = [
            '$controllerFactoryString'         => '',
            '$serviceFactoryString'            => '',
            '$routeString'                     => '',
            '$navigationString'                => '',
            '$authorizationControllerString'   => '',
            '$authorizationRouteString'        => '',
            '$authorizationResourceString'     => '',
            '$authorizationRuleProviderString' => '',
            '$dependentRepoString'             => '',
            '$displayOptionsString'            => '',
        ];
        
        foreach($this->tableDescription as $key=>$des){
            $fieldname = $this->CreateCrudModuleBootStrapService->colNameToFieldName($key);
            $entityName = $this->CreateCrudModuleBootStrapService->tableToEntityName($key);
            $ret['$dependentRepoString'] .= '$dependentRepos["'.$key.'"] = '
                    . '$em->getRepository("\__ModuleName__\Entity\\'.$entityName.'");';
        }
        
        $ret['$dependentRepoString'] = $this->replaceNames($ret['$dependentRepoString'], $moduleName, $tableNames[0]);
        
        foreach($tableNames as $tableName){
            $ret['$controllerFactoryString']         .= "\n".$this->replaceNames($controllerFactoryString, $moduleName, $tableName);
            $ret['$serviceFactoryString']            .= "\n".$this->replaceNames($serviceFactoryString, $moduleName, $tableName);
            $ret['$routeString']                     .= "\n".$this->replaceNames($routeString, $moduleName, $tableName);
            $ret['$navigationString']                .= "\n".$this->replaceNames($navigationString, $moduleName, $tableName);
            $ret['$authorizationControllerString']   .= "\n".$this->replaceNames($authorizationControllerString, $moduleName, $tableName);
            $ret['$authorizationRouteString']        .= "\n".$this->replaceNames($authorizationRouteString, $moduleName, $tableName);
            $ret['$authorizationResourceString']     .= "\n".$this->replaceNames($authorizationResourceString, $moduleName, $tableName);
            $ret['$authorizationRuleProviderString'] .= "\n".$this->replaceNames($authorizationRuleProviderString, $moduleName, $tableName);
            $ret['$displayOptionsString']            .= "\n".$this->replaceNames($displayOptionsString, $moduleName, $tableName);
        }
        $this->configString = $ret;
        return $ret;
    }
}
