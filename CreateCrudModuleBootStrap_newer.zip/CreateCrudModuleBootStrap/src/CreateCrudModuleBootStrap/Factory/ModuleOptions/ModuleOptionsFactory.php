<?php
namespace CreateCrudModuleBootStrap\Factory\ModuleOptions;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions;

class ModuleOptionsFactory implements FactoryInterface
{
    public function __invoke(\Interop\Container\ContainerInterface $serviceManager, $requestedName, array $options = null)
    {
        return $this->createService($serviceManager);
    }
    
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $config = $serviceLocator->get('Config');
        return new ModuleOptions(isset($config['create_crud_modulemodule_options']) ? $config['create_crud_modulemodule_options'] : []);        
    }
}
