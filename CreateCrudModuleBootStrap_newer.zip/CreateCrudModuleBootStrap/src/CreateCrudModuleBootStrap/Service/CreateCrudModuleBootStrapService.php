<?php
namespace CreateCrudModuleBootStrap\Service;

use Doctrine\Common\Persistence\ObjectManager;

use CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions;

class CreateCrudModuleBootStrapService
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    protected $objectManager;
    
    /**
     * @var \CreateCrudModuleBootStrap\ModuleOptions\ModuleOptions
     */
    protected $options;
    
    /**
     * @param \Doctrine\Common\Persistence\ObjectManager    $objectManager
     */
    public function __construct(ModuleOptions $options, ObjectManager $objectManager)
    {
        $this->objectManager = $objectManager;
        $this->options       = $options;
    }
    
    public function getEntityManager(){
        return $this->objectManager;
    }
    
    public function getTableNames(){
        $tables = $this->objectManager->getConnection()->query("SHOW TABLES;")->fetchAll(\PDO::FETCH_NUM);
        $ret = [];
        foreach($tables as $key=>$value){
            $ret[] = $value[0];
        }
        
        return $ret;
    }
    
    public function getAssociation(){
        $databaseName  = $this->objectManager->getConnection()->getDatabase();
        $query = "SELECT
        `TABLE_NAME`,
        `COLUMN_NAME`,
        `REFERENCED_TABLE_NAME`,
        `REFERENCED_COLUMN_NAME`
        FROM `information_schema`.`KEY_COLUMN_USAGE`
        WHERE `CONSTRAINT_SCHEMA` = '$databaseName' AND
        `REFERENCED_TABLE_SCHEMA` IS NOT NULL AND
        `REFERENCED_TABLE_NAME` IS NOT NULL AND
        `REFERENCED_COLUMN_NAME` IS NOT NULL;";
        $association = $this->objectManager->getConnection()->query($query)->fetchAll();
        
        $ret = [];
        foreach($association as $a){
            $ret[$a['TABLE_NAME']][$a['COLUMN_NAME']] = $a;
        }
        return $ret;
    }
    
    public function getTableDescription(){
        $tables = $this->getTableNames();
        $tableDescription = [];
        foreach($tables as $tableName){
            $query = "DESCRIBE $tableName;";
            $description = $this->objectManager->getConnection()->query($query)->fetchAll();
            foreach($description as $d){
                $tableDescription[$tableName][$d['Field']] = $d;
            }
        }
        return $tableDescription;
    }
    
    public function getEntityNames($tableNames=[]){
        $entityNames = [];
        foreach($tableNames as $t){
            $entityNames[] = str_replace(' ', '', ucwords(str_replace('_', ' ', $t)));
        }
        return $entityNames;
    }
    
    public function tableToEntityName($tableName){ //user_table to UserTable
        return str_replace(' ', '', ucwords(str_replace('_', ' ', $tableName)));
    }
    
    public function colNameToFieldName($colName){ //user_name to userName
        return lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', $colName))));
    }
}

