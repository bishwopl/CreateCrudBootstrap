<?php

namespace __ModuleName__\Form\__EntityName__;

use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Zend\Form\Form;
use Zend\InputFilter\InputFilterProviderInterface;

class __EntityName__Form extends Form implements InputFilterProviderInterface {

    public function __construct(\__ModuleName__\Service\__EntityName__Service $__EntityNameCamelCase__Service, $translator, $id = NULL) {
        parent::__construct('__EntityNameCamelCase___form');

        $objectManager = $__EntityNameCamelCase__Service->getEntityManager();
        $this->setHydrator(new DoctrineHydrator($objectManager));

        $this->setAttribute('enctype', 'multipart/form-data');
        $this->setAttribute('METHOD', 'POST');
        $this->setAttribute('class', 'form-horizontal');

        $this->add([
            'type' => 'Zend\Form\Element\Hidden',
            'name' => 'id',
            'options' => [
                'label' => '',
            ],
            'attributes' => [
                'id' => 'id',
            ],
        ]);

        $formFieldString;
        
        $this->add([
            'name' => 'submit',
            'attributes' => [
                'type' => 'submit',
                'value' => 'Submit',
                'id' => 'submitButton',
                'class' => 'btn btn-primary'
            ],
        ]);
    }

    public function getInputFilterSpecification() {
        return [
            $formValidationString
        ];
    }

}
