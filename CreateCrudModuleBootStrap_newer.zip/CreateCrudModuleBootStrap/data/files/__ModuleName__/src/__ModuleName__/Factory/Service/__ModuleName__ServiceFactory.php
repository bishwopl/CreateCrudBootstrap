<?php
namespace __ModuleName__\Factory\Service;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

use __ModuleName__\Service\__ModuleName__Service__;

class __ModuleName__Service__Factory implements FactoryInterface
{
    public function __invoke(\Interop\Container\ContainerInterface $serviceManager, $requestedName, array $options = null)
    {
        return $this->createService($serviceManager);
    }
    
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     *
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $em                  = $serviceLocator->get('doctrine.entitymanager.orm_default');
        $options             = $serviceLocator->get('\__ModuleName__Service__\ModuleOptions\ModuleOptions');
        
        return new __ModuleName__Service__($options, $em);
    }
}

