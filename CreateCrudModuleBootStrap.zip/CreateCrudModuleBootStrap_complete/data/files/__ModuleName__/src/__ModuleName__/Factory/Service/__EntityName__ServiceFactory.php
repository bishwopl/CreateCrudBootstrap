<?php
namespace __ModuleName__\Factory\Service;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

use __ModuleName__\Service\__EntityName__Service;

class __EntityName__ServiceFactory implements FactoryInterface
{
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     *
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $em                  = $serviceLocator->get('doctrine.entitymanager.orm_default');
        $options             = $serviceLocator->get('\__ModuleName__\Options\ModuleOptions');
        $repository          = $em->getRepository('\__ModuleName__\Entity\__EntityName__');
        $entity              = new \__ModuleName__\Entity\__EntityName__();
        return new __EntityName__Service($options, $em, $repository, $entity);
    }
}

