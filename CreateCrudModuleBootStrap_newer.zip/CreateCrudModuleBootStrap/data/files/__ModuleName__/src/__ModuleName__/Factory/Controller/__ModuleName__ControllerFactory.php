<?php
namespace __ModuleName__\Factory\Controller;

use __ModuleName__\Controller\__ModuleName__Controller;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class __ModuleName__ControllerFactory implements FactoryInterface
{
    public function __invoke(\Interop\Container\ContainerInterface $serviceManager, $requestedName, array $options = null)
    {
        return $this->createService($serviceManager);
    }
    
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     *
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $realServiceLocator  = $serviceLocator->getServiceLocator();
        $em                  = $realServiceLocator->get('doctrine.entitymanager.orm_default');
        $options             = $realServiceLocator->get('\__ModuleName__\ModuleOptions\ModuleOptions');
        $__ModuleNameCamelCase__Service      = $realServiceLocator->get('\__ModuleName__\Service\__ModuleName__Service');
        $translator          = $realServiceLocator->get('translator');
        return new __ModuleName__Controller($options, $__ModuleNameCamelCase__Service, $em, $translator);
    }
}

