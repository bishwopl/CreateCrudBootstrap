<?php
namespace __ModuleName__\Factory\ModuleOptions;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use __ModuleName__\ModuleOptions\ModuleOptions;

class ModuleOptionsFactory implements FactoryInterface
{

    public function __invoke(\Interop\Container\ContainerInterface $serviceManager, $requestedName, array $options = null)
    {
        return $this->createService($serviceManager);
    }
    
    /**
     * Create service
     *
     * @param ServiceLocatorInterface $serviceLocator
     * @return mixed
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $config = $serviceLocator->get('Config');
        return new ModuleOptions(isset($config['__ModuleNameWithUnderscore___module_options']) ? $config['__ModuleNameWithUnderScore___module_options'] : []);        
    }
}
