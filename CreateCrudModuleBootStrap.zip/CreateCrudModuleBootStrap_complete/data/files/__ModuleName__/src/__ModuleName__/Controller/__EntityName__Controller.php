<?php
namespace __ModuleName__\Controller;

use Doctrine\Common\Persistence\ObjectManager;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use __ModuleName__\Service\__EntityName__Service;
use __ModuleName__\ModuleOptions\ModuleOptions;
use __ModuleName__\Form\__EntityName__\__EntityName__Form;

class __EntityName__Controller extends AbstractActionController
{
    /**
     * @var \Doctrine\Common\Persistence\ObjectManager
     */
    protected $objectManager;
    
    /**
     * @var \__ModuleName__\Service\__EntityName__Service
     */
    protected $__EntityNameCamelCase__Service;
    
    /**
     * @var \__ModuleName__\ModuleOptions\ModuleOptions
     */
    protected $options;
    
    protected $translator;

    public function __construct(
            ModuleOptions $options,
            __EntityName__Service $__EntityNameCamelCase__Service,
            ObjectManager $em, 
            $translator)
    {
        $this->options       = $options;
        $this->__EntityNameCamelCase__Service   = $__EntityNameCamelCase__Service;
        $this->objectManager = $em;
        $this->translator    = $translator;
    }
    
    public function indexAction() 
    {
        $viewModel =  new ViewModel([
            '__EntityNameCamelCase__Form'   => new __EntityName__Form($this->__EntityNameCamelCase__Service, $this->translator)
        ]);
        return $viewModel;
    }


    public function listAction()
    {
        $viewModel = new ViewModel();
        $viewModel->setTerminal(true);
        
        $searchableColumns = ['id'];
        
        $startIndex  = 0;
        $pageSize    = 10;
        $orderStyle  = [];
        $order[]     = [];
        $searchTerms = [];
        $request     = [];
        
        if($this->getRequest()->isPost()){
            $request = $this->getRequest()->getPost()->toArray();
            $columns = $request['columns'];
            $startIndex = (int)$request['start'];
            $pageSize = (int)$request['length'];
            $order = $request['order'];
            $search = $request['search'];
            
            foreach($order as $o){
                $orderStyle[] = [$columns[$o['column']]['data'], $o['dir']];
            }
            
            foreach($searchableColumns as $s){
                $searchTerms = array_merge($searchTerms, [$s=>$search['value']]);
            }
        }

        $list = $this->__EntityNameCamelCase__Service->getListOfRecords(
                $searchTerms,
                $orderStyle, $startIndex, $pageSize
        );
        
        if($list!=false){
            $viewModel->setVariable('draw', (isset($request['draw'])?(int)$request['draw']:NULL));
            $viewModel->setVariable('status', 'OK');
            $viewModel->setVariable('recordsTotal' , (int)$list['recordsTotal']);
            $viewModel->setVariable('records' , $list['data']);
            $viewModel->setVariable('start', $startIndex);
        }
        else{
            $viewModel->setVariable('status', 'ERROR');
            $viewModel->setVariable('message', serialize($request));
        }
        
        return $viewModel;
    }
    
    public function addAction()
    {
        $viewModel =  new ViewModel();
        $viewModel->setTerminal(true);
        
        $form = new __EntityName__Form($this->__EntityNameCamelCase__Service, $this->translator);
        $form->setAttribute("action", "/__ModuleNameWithDash__/__EntityNameWithDash__/add");
        $entity = $this->__EntityNameCamelCase__Service->getEntity();
        $form->bind($entity);
        
        if ($this->getRequest()->isPost()) {
            $data = $this->getRequest()->getPost()->toArray();
            $form->setData($data);
            
            if($form->isValid()){
                 try{
                    $this->__EntityNameCamelCase__Service->saveRecord($entity);
                    $viewModel->setVariable('Result', 'OK');
                }
                catch (\Exception $e){
                    $viewModel->setVariable('Result', 'ERROR');
                    $viewModel->setVariable('message', $e->getMessage());
                }
            }
            else{
                $viewModel->setVariable('message', $this->translator->translate('Form is not valid'));
            }
            $viewModel->setVariable('data', $data);
        }

        $viewModel->setVariable('__EntityNameCamelCase__Form', $form);
        return $viewModel;
    }
    
    public function editAction()
    {
        $viewModel = new ViewModel();
        $viewModel->setTerminal(true);
        $form = new __EntityName__Form($this->__EntityNameCamelCase__Service, $this->translator);
        
        $id = (int) $this->params() ->fromRoute('id' , 0);
        if (! $id) {  exit; }
        $entity = $this->__EntityNameCamelCase__Service->findRecordById($id);
        if($entity===false){ exit; }
        $form->bind($entity);
        $form->setAttribute('action', '/__ModuleNameWithDash__/__EntityNameWithDash__/edit/'.$entity->getId());
        $viewModel->setVariable('entity', $entity);
        
        if ($this->getRequest()->isPost()) { 
            $data   = $this->getRequest()->getPost()->toArray();
            $form->setData($data);
            if($form->isValid()){
                try{
                    $this->__EntityNameCamelCase__Service->saveRecord($entity);
                    $viewModel->setVariable('Result', 'OK');
                }
                catch (\Exception $e){
                    $viewModel->setVariable('Result', 'ERROR');
                    $viewModel->setVariable('message', $e->getMessage());
                }
            }
        }
        $viewModel->setVariable('__EntityNameCamelCase__Form', $form);
        return $viewModel;
    }
    
    public function deleteAction()
    {
        $viewModel = new ViewModel();
        $viewModel->setTerminal(true);
        
        $id = (int) $this->params() ->fromRoute('id' , 0);
        if (! $id) {  exit;  }
        $entity = $this->__EntityNameCamelCase__Service->findRecordById($id);
        if($entity===false){ exit; }

        $viewModel->setVariable('entity', $entity);
        
        if ($this->getRequest()->isPost()) { 
            try{
                $this->__EntityNameCamelCase__Service->deleteRecord($entity);
                $viewModel->setVariable('Result', 'OK');
            }
            catch (\Exception $e){
                $viewModel->setVariable('Result', 'ERROR');
                $viewModel->setVariable('message', $e->getMessage());
            }
        }
        return $viewModel;
    }
}
