<?php
namespace __ModuleName__\ModuleOptions;

use Zend\Stdlib\AbstractOptions;

class ModuleOptions extends AbstractOptions{  
    protected $__strictMode__              = false;
    protected $testElement                 = 'Hi';

    public function __construct($options = null) {
        parent::__construct($options);
    }

    public function getTestElement(){
        return $this->testElement;
    }
    
    public function setTestElement($testElement){
        $this->testElement = $testElement;
        return $this;
    }
}

